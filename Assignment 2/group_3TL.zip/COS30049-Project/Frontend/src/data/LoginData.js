//Nguyen Do Nhat Nam-104061616
export const LoginData = [
  {
    src: "./images/icon/person.png",
    name: "userName",
    type: "text",
    id: "username",
    placeholder: "Username",
    required: "required",
    alt: "Username Icon",
  },
  {
    src: "./images/icon/lock.png",
    type: "password",
    name: "password",
    id: "password",
    placeholder: "Password",
    required: "required",
    alt: "Password Icon",
  },
];
