// Tran Thanh Minh - 103809048
import React from "react";

const FooterContainer = ({ children }) => {
  return <div className="basis-1/3 text-white mx-8 my-8">{children}</div>;
};

export default FooterContainer;
