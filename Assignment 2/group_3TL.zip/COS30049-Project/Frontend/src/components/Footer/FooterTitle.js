// Tran Thanh Minh - 103809048
import React from "react";

const FooterTitle = ({ children }) => {
  return <div className="text-3xl font-bold mb-6">{children}</div>;
};

export default FooterTitle;
