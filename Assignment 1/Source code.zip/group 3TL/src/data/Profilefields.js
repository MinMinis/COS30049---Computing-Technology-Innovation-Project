//Nguyen Do Nhat Nam-104061616
const Profilefields = [
  [
    { label: "Email", type: "email", name: "email" },
    { label: "Phone", type: "tel", name: "phone" },
  ],
  [
    { label: "Password", type: "password", name: "password" },
    { label: "Confirm Password", type: "password", name: "confirmPassword" },
  ],
];
export { Profilefields };
