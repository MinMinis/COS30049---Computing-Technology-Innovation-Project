export const FooterInfo = [
  [{ member: "Nhat Nam" }, { member: "Thanh Minh" }, { member: "Quoc Thang" }],
  [{ info: "+84 982243038" }, { info: "namndnsws00154@fpt.edu.vn" }],
];
