//Nguyen Do Nhat Nam-104061616
const inputFields = [
  {
    id: "email",
    label: "Email",
    type: "text",
    name: "email",
    placeholder: "Email",
    icon: "mail",
  },
  {
    id: "phone",
    label: "Phone Number",
    type: "text",
    name: "phoneNumber",
    placeholder: "Phone Number",
    icon: "phone",
  },
  {
    id: "pass",
    label: "Password",
    type: "password",
    name: "password",
    placeholder: "Password",
    icon: "lock",
  },
  {
    id: "retype-password",
    label: "Re-type Password",
    type: "password",
    name: "retypePassword",
    placeholder: "Re-type Password",
    icon: "lock",
  },
];
export { inputFields };
