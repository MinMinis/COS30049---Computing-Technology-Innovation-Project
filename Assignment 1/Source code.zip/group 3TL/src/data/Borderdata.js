//Nguyen Do Nhat Nam-104061616
const BorderData = [
  {
    image: "./images/homepart/decentralized.png",
    alt: "Logo 1",
    title: "Decentralized Trading",
  },
  {
    image: "./images/homepart/trade.png",
    alt: "Logo 2",
    title: "Trade Digital Assets",
  },
];
export { BorderData };
