export const FAKE_USER = {
  name: "Thanh Minh",
  username: "admin",
  email: "minh@gmail.com",
  password: "admin",
  phone: 982243038,
  miningReward: 0.001,
  address: "0xc127911a737a5fde71ca1edd7ed44aebf5182e6f",
  balance: 10.34,
};
