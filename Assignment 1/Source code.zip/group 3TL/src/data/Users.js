export const Users = [
  {
    id: 1,
    name: "Thanh Minh",
    image: "./images/users/user1.jpg",
    description: "Hello I am Minh",
    position: "Teacher",
  },
  {
    id: 2,
    name: "Thanh Minh",
    image: "./images/users/user1.jpg",
    description: "Hello I am Minh",
    position: "Teacher",
  },
];
